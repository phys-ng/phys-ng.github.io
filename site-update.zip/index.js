"use strict";

const reduction = window.matchMedia("(prefers-reduced-motion: reduce)");

function autoPlay(video) {
  if (!reduction.matches) {
    video.play().catch(() => {});
  }
}

function renderVisualReference(video, canvas) {
  const context = canvas.getContext("2d");
  if (!context) return;

  // The original presentation puts the moving reference above the output.
  // Read that region from the same decoded frame as the visible output.
  function draw() {
    if (video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA) return;
    context.drawImage(video, 814, 24, 278, 156, 0, 0, canvas.width, canvas.height);
    canvas.hidden = false;
  }

  video.addEventListener("loadeddata", draw);
  video.addEventListener("seeked", draw);
  if ("requestVideoFrameCallback" in video) {
    function drawFrame() {
      draw();
      video.requestVideoFrameCallback(drawFrame);
    }
    video.requestVideoFrameCallback(drawFrame);
  } else {
    function drawDuringPlayback() {
      if (video.paused) return;
      draw();
      requestAnimationFrame(drawDuringPlayback);
    }
    video.addEventListener("play", drawDuringPlayback);
  }
}

const observer = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    const video = entry.target;
    if (entry.isIntersecting) {
      autoPlay(video);
    } else {
      video.pause();
    }
  }
}, { threshold: 0.38 });

for (const panel of document.querySelectorAll("[data-interactive]")) {
  const buttons = Array.from(panel.querySelectorAll("[data-choice]"));
  const entries = JSON.parse(panel.querySelector("[data-choices]").textContent);
  const preview = panel.querySelector("video");
  const source = preview.querySelector("source");
  const caption = panel.querySelector("[data-caption]");
  const input = panel.querySelector("[data-input]");
  const referenceVideo = panel.querySelector("[data-reference-video]");
  if (referenceVideo) renderVisualReference(preview, referenceVideo);
  observer.observe(preview);

  buttons.forEach((button, index) => {
    button.addEventListener("click", () => {
      if (button.getAttribute("aria-pressed") === "true") return;
      const selection = entries[index];
      const base = `media/${selection.key}`;
      const movie = referenceVideo ? `${base}-sync` : base;
      const wasPlaying = !preview.paused;
      for (const option of buttons) {
        option.setAttribute("aria-pressed", String(option === button));
      }
      preview.poster = `${movie}.webp`;
      preview.setAttribute("aria-label", selection.label);
      source.src = `${movie}.mp4`;
      caption.textContent = selection.caption;
      if (referenceVideo) {
        referenceVideo.hidden = true;
        input.src = `${base}-input.webp`;
        panel.querySelector("[data-prompt]").textContent = selection.prompt;
        panel.querySelector("[data-negative]").textContent = selection.negative;
        panel.querySelector("[data-reference-image]").src = `${base}-reference.webp`;
        panel.querySelector("[data-reference]").textContent = selection.reference;
      }
      preview.load();
      if (wasPlaying) preview.play().catch(() => {});
      else if (referenceVideo) autoPlay(preview);
    });
  });
}
